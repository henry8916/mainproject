<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="TilesetFloor32" tilewidth="32" tileheight="32" tilecount="572" columns="22">
 <image source="TilesetFloor32.png" width="704" height="834"/>
</tileset>
