<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="TilesetFloorDetail32" tilewidth="32" tileheight="32" tilecount="80" columns="16">
 <image source="TilesetFloorDetail32.png" width="512" height="160"/>
</tileset>
