<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="TilesetDesert32" tilewidth="32" tileheight="32" tilecount="240" columns="20">
 <image source="TilesetDesert32.png" width="640" height="384"/>
</tileset>
