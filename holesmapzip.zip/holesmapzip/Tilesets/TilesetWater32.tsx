<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="TilesetWater32" tilewidth="32" tileheight="32" tilecount="476" columns="28">
 <image source="TilesetWater32.png" width="896" height="544"/>
</tileset>
