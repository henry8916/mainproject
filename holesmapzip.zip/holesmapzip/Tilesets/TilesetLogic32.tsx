<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="TilesetLogic32" tilewidth="32" tileheight="32" tilecount="80" columns="8">
 <image source="TilesetLogic32.png" width="256" height="320"/>
</tileset>
